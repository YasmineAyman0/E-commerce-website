var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}


const open = document.getElementById('btn');
		const modal_container = document.getElementById('modal');
		const close = document.getElementById('close');

		open.addEventListener('click', () => {
			modal_container.classList.add('show')

		});

		close.addEventListener('click', () => {
			modal_container.classList.remove('show')

		});

		const open2 = document.getElementById('btn2');
		const modal_container2 = document.getElementById('modal2');
		const close2 = document.getElementById('close2');

		open2.addEventListener('click', () => {
			modal_container2.classList.add('show')

		});

		close2.addEventListener('click', () => {
			modal_container2.classList.remove('show')

		});

		const open3 = document.getElementById('btn3');
		const modal_container3 = document.getElementById('modal3');
		const close3 = document.getElementById('close3');

		open3.addEventListener('click', () => {
			modal_container3.classList.add('show')

		});

		close3.addEventListener('click', () => {
			modal_container3.classList.remove('show')

		});

		const open4 = document.getElementById('btn4');
		const modal_container4 = document.getElementById('modal4');
		const close4 = document.getElementById('close4');

		open4.addEventListener('click', () => {
			modal_container4.classList.add('show')

		});

		close4.addEventListener('click', () => {
			modal_container4.classList.remove('show')

		});

		const open5 = document.getElementById('btn5');
		const modal_container5 = document.getElementById('modal5');
		const close5 = document.getElementById('close5');

		open5.addEventListener('click', () => {
			modal_container5.classList.add('show')

		});

		close5.addEventListener('click', () => {
			modal_container5.classList.remove('show')

		});

		const open6 = document.getElementById('btn6');
		const modal_container6 = document.getElementById('modal6');
		const close6 = document.getElementById('close6');

		open6.addEventListener('click', () => {
			modal_container6.classList.add('show')

		});

		close6.addEventListener('click', () => {
			modal_container6.classList.remove('show')

		});

		const open7 = document.getElementById('btn7');
		const modal_container7 = document.getElementById('modal7');
		const close7 = document.getElementById('close7');

		open7.addEventListener('click', () => {
			modal_container7.classList.add('show')

		});

		close7.addEventListener('click', () => {
			modal_container7.classList.remove('show')

		});

		const open8 = document.getElementById('btn8');
		const modal_container8 = document.getElementById('modal8');
		const close8 = document.getElementById('close8');

		open8.addEventListener('click', () => {
			modal_container8.classList.add('show')

		});

		close8.addEventListener('click', () => {
			modal_container8.classList.remove('show')

		});

		const open9 = document.getElementById('btn9');
		const modal_container9 = document.getElementById('modal9');
		const close9 = document.getElementById('close9');

		open9.addEventListener('click', () => {
			modal_container9.classList.add('show')

		});

		close9.addEventListener('click', () => {
			modal_container9.classList.remove('show')

		});


