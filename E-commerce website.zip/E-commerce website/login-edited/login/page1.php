<?php 

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: logout.php");
}

?>

<html>
<head>
    <link rel="stylesheet" href="r2.css">
    <link rel="icon" href="reem.png" type="image/gif">

    <title>
        fashion
    </title>

</head>
<body>
  <?php echo "<h1>Welcome " . $_SESSION['username'] . "</h1>"; ?>
    <div class="container">
        <nav class="topnav">
            <p >Concept</p>
           <!-- <ul>
                <li>
                    <a href="home.html">Home</a>
                </li>
                <li>
                    <a href="#">Sections</a>
                    <ul>
                        <li><a href="beauty.html">Beauty</a></li>
                        <li><a href="index.html">Electronics</a></li>
                        <li><a href="furniture.html">Furniture</a></li>
                        <li><a href="fashion.html">Fashion</a></li>
                    </ul>
                </li>
                <li>
                    <a href="ContactUs.html">Contact us</a>
                </li>
                <li>
                    <a href="About Customer.html">About Customer</a>
                </li>
                <li>
                    <a href="">About Us</a>
                    <ul>
                        <li><a>Yasmine Ayman Mohamed</a></li>
                        
                    </ul>
                </li>
            </ul>-->
			<br>
			<br>
			 
             <a href="it1.html"><p style="color:white;font-size:20px;">
			                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;food</p></a>
             <a href="index2.html"><p style="color:white;font-size:20px;">
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Electronics</p></a>
             <a href="page4.html"><p style="color:white;font-size:20px;">
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bags</p></a>
			 <a href="page3.html"><p style="color:white;font-size:20px;">
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;jackets</p></a>
			 		 <a href="page5.html"><p style="color:white;font-size:20px;">
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;trousers</p></a>
			 <a href="page2.html"><p style="color:white;font-size:20px;">
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dresses</p></a>
			 <a href="page6.html"><p style="color:white;font-size:20px;">
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;About us</p></a>
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			 
			<a href="logout.php">
            <button>Log out</button>
            </a> 
			
			
            
            
            <input type="text" name="" id="" placeholder="Search">
        </nav>
    </div>
    <div class="slider">
        <ul>
            <li>
                <img src="EIS-Andora-1318x318-en.jpg" alt="" />
                <h1> </h1><br />
            </li>
            <li>
                <img src="EIS-Converse-1318x318-en.jpg" alt="" />
                <h1> </h1><br />
            </li>
            <li>
                <img src="EIS-Reebok-1318x318-en.jpg" alt="" />
                <h1> </h1><br />
            </li>
            <li>
                <img src="EIS-Fossil-1318x318-en.jpg" alt="" />
                <h1> </h1><br />
            </li>
            <li>
                <img src="EIS-G-shock-1318x318-en.jpg" alt="" />
                <h1> </h1><br />
            </li>
        </ul>
    </div>
    <div class="womanfashion">
        <div class="fashion">
            <img src="item_XXL_9113337_9625242.jpg" alt="dresses">
            <h3>
                <a href="page2.html">
                    Dresses
                </a>
            </h3>
        </div>
        <div class="fashion">
            <img src="1603792935-1171970467.jpg" alt="jackets & coats">
            <h3>
                <a href="page3.html">
                    Jackets & Coats
                </a>
            </h3>
        </div>
        <div class="fashion">
            <img src="1603793102-2084805.jpg" alt=" bags & wallets">
            <h3>
                <a href="page4.html">
                    Bags & Wallets
                </a>
            </h3>
        </div>
        <div class="fashion">
            <img src="1603792716-1617365026.jpg" alt="pants">
            <h3>
                <a href="page5.html">
                    Pants
                </a>
            </h3>
        </div>
        <div class="fashion">
            <img src="1603792863-573496756.jpg" alt="sports shoeses">
            <h3>
                <a href="page5.html">
                    Sports shoeses
                </a>
            </h3>
        </div>
        <div class="fashion">
            <img src="1603793290-1614793775.jpg" alt="watches">
            <h3>
                <a href="page7.html">
                    Watches
                </a>
            </h3>
        </div>
        <div class="fashion">
            <img src="1603793004-3456636642.jpg" alt="heels">
            <h3>
                <a href="page8.html">
                    heels
                </a>
            </h3>
        </div>
        <div class="clear fix">

        </div>

        <div class="offers">
            <img src="L_1622110160_GW-MB-main-en.jpg" alt="hot offers">
            <h3>
                <a href="">
                    Get extra 5% discount
                </a>
            </h3>
        </div>
    </div>
	
	<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {
  var myDropdown = document.getElementById("myDropdown");
    if (myDropdown.classList.contains('show')) {
      myDropdown.classList.remove('show');
    }
  }
}
</script>
	
	
</body>
</html>